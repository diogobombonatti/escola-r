package com.example;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class PrimaryController {
    
    @FXML TextField txtNome;
    @FXML TextField txtTurma;
    @FXML TextField txtRm;
    @FXML ListView<Aluno> lista;

    ArrayList<Aluno> alunos = new ArrayList<>();

    public void adicionarAluno(){
        var aluno = new Aluno(
            txtNome.getText(),
            txtTurma.getText(),
            Integer.valueOf( txtRm.getText() )
        );

        alunos.add(aluno);

        txtNome.clear();
        txtTurma.clear();
        txtRm.clear();

        atualizarTela();
    }

    public void atualizarTela(){
        ordenar();
        lista.getItems().clear();

        //alunos.forEach(nome -> txtAlunos.appendText(nome + "\n"));

        for (var aluno: alunos){
            lista.getItems().add(aluno);
        }
    }


    private void ordenar(){
        //anonymous class
        alunos.sort( (o1, o2) -> o1.nome().compareToIgnoreCase(o2.nome()) );
    }

}

//inner class

